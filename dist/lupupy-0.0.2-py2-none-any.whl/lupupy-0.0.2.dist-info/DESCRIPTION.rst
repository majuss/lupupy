lupupy is a python3 interface forthe Lupus Electronics alarm panel.Its intented to get used in varioussmart home services to get a fullintegration of all you devices.


